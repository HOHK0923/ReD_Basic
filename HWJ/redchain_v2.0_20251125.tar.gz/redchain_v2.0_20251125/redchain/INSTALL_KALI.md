# RedChain - Kali Linux 설치 가이드

## 🐉 Kali Linux에서 5분 만에 설치하기

### 1단계: 압축 해제

```bash
# 다운로드한 위치로 이동
cd ~/Downloads

# 압축 해제
tar -xzf redchain_v1.0_*.tar.gz
cd redchain
```

### 2단계: 설치 스크립트 실행

```bash
chmod +x install.sh
./install.sh
```

**설치 과정에서 질문:**
- 필수 도구 설치? → **y** (nmap, ffuf 등)
- Tor 설치? → **y** (익명 스캔용, 이미 설치되어 있을 수 있음)
- 전역 명령어 사용? → **y** (중요!)

### 3단계: 실행

```bash
redchain
```

**또는**

```bash
./redchain.py
```

---

## 🎯 빠른 시작

```bash
redchain

redchain> set target <타겟 IP>
redchain> set ssh_user <사용자명>
redchain> auto full
```

---

## ⚡ Kali Linux 전용 팁

### 1. Tor가 이미 설치되어 있는 경우

```bash
# Tor 서비스 시작
sudo systemctl start tor

# 자동 시작 설정
sudo systemctl enable tor
```

### 2. nmap을 proxychains와 함께 사용

```bash
redchain> set tor on
redchain> scan
```

### 3. 여러 타겟 관리

```bash
# 타겟 1
redchain> set target 192.168.1.100
redchain> scan

# 타겟 2로 전환
redchain> set target 192.168.1.101
redchain> scan
```

---

## 🔧 의존성

Kali Linux에는 대부분의 도구가 이미 설치되어 있습니다:

- ✅ Python 3
- ✅ nmap
- ✅ Tor
- ✅ proxychains4
- ⚠️ ffuf (설치 필요할 수 있음)

### ffuf 수동 설치

```bash
# 방법 1: apt
sudo apt install ffuf

# 방법 2: Go
go install github.com/ffuf/ffuf@latest
```

---

## 📁 디렉토리 구조

```
redchain/
├── redchain.py              # 메인 CLI 도구
├── install.sh               # 설치 스크립트
├── README.md                # 문서
├── QUICKSTART.md            # 빠른 시작
├── INSTALL_KALI.md          # 이 파일
├── 01_AWS_IMDS_Attack/      # AWS 공격 스크립트
├── 02_Site_Defacement/      # 웹 변조 스크립트
└── 03_Documentation/        # 상세 문서
```

---

## ⚠️ 법적 고지

이 도구는 교육 및 연구 목적으로만 사용하세요.
승인되지 않은 시스템에 사용 시 법적 책임을 질 수 있습니다.

---

**Kali Linux에 최적화되었습니다!** 🐉
